# Google AI Studio Prompt — Scholarship Application & Multi-Level Verification System

Use this prompt in Google AI Studio to understand, extend, debug, or regenerate this project.

---

You are a senior Java web application engineer. Build and maintain a complete **Scholarship Application & Multi-Level Verification System** as an Eclipse/Tomcat web application.

## Mandatory technology stack

- Java 11+
- JSP (JavaServer Pages)
- Jakarta/Javax APIs according to the selected Tomcat version; for this supplied project use **Apache Tomcat 9 and javax.servlet 4.0.1**
- Servlets
- JDBC
- MySQL 8+
- HTML5
- CSS3
- JavaScript
- Bootstrap 5
- Maven WAR project
- Eclipse IDE for Enterprise Java and Web Developers

Do not replace the stack with Spring Boot, Node.js, React, Angular, Python, PHP, Firebase, MongoDB, or another database/framework unless explicitly requested.

## Project objective

Create a role-based scholarship portal where students submit scholarship applications and supporting documents. Applications pass through multiple verification levels. Officers can approve, reject, or return an application for correction. Every important action must be auditable.

## Roles

1. STUDENT
2. DOCUMENT_OFFICER
3. COLLEGE_OFFICER
4. DISTRICT_OFFICER
5. FINAL_AUTHORITY
6. ADMIN

## Required workflow

```text
Student
  |
  | Submit application
  v
SUBMITTED
  |
  v
DOCUMENT_OFFICER
  |
  +--> RETURNED --> Student corrects/uploads documents --> SUBMITTED
  |
  +--> REJECTED
  |
  +--> APPROVED
          |
          v
INSTITUTE_VERIFICATION
          |
          v
COLLEGE_OFFICER
          |
          +--> RETURNED
          +--> REJECTED
          +--> APPROVED
                  |
                  v
DISTRICT_VERIFICATION
                  |
                  v
DISTRICT_OFFICER
                  |
                  +--> RETURNED
                  +--> REJECTED
                  +--> APPROVED
                          |
                          v
FINAL_REVIEW
                          |
                          v
FINAL_AUTHORITY
                          |
                          +--> RETURNED
                          +--> REJECTED
                          +--> APPROVED
```

Never create a state that cannot be reached by a valid transition. Never allow an officer to skip a required verification level.

## Core modules

### Student
- Registration/login
- Dashboard
- View available scholarships
- Eligibility checking
- New application
- Application status tracking
- Upload required documents
- View returned/rejection reason
- Correct and resubmit returned applications
- Logout

### Officer
- Secure role-based login
- Dashboard showing only applications assigned to the officer's verification stage
- View application details
- View submitted documents
- Approve
- Reject with mandatory reason
- Return with mandatory correction reason
- Add verification remarks

### Admin
- Manage users/roles
- View applications
- View audit logs
- Monitor workflow

### System services
- Eligibility service
- Fraud/risk scoring service
- Workflow service
- JDBC DAO layer
- Audit logging
- Authentication and authorization filters
- Security headers

## Database requirements

Use MySQL and normalized relational tables for at least:

- users
- scholarships
- applications
- documents
- verifications
- audit_logs

Use primary keys, foreign keys, indexes, NOT NULL constraints, timestamps, and suitable status fields.

Use PreparedStatement for all user-supplied SQL values. Never concatenate user input into SQL.

## Security requirements

- Use hashed passwords; do not store plaintext passwords in production.
- Validate session authentication and role on every protected servlet.
- A student may access only their own applications/documents.
- Officers may act only on applications in their permitted workflow stage.
- Validate uploaded document type, size, application ownership, and required metadata.
- Do not trust hidden form fields for authorization.
- Use server-side validation even when JavaScript validation exists.
- Add basic security headers.
- Use POST for state-changing operations.
- Do not expose database credentials in JSP pages.

## JSP requirements

Keep JSP pages focused on presentation. Business logic belongs in Java services/DAOs/servlets.

Use JSTL/EL where appropriate rather than Java scriptlets.

Use Bootstrap 5 for responsive UI.

## Java package structure

Use a structure similar to:

```text
src/main/java/com/scholarship/
    model/
    dao/
    service/
    servlet/
    filter/
    util/
```

Web files:

```text
src/main/webapp/
    index.jsp
    student/
    officer/
    assets/
    WEB-INF/
```

## Workflow rules

The initial application status must be `SUBMITTED`.

The document officer must query `SUBMITTED` applications. Do NOT use an obsolete `DOCUMENT_VERIFICATION` state unless it is explicitly implemented everywhere.

After document verification approval:

```text
SUBMITTED -> INSTITUTE_VERIFICATION
```

Then:

```text
INSTITUTE_VERIFICATION -> DISTRICT_VERIFICATION
DISTRICT_VERIFICATION -> FINAL_REVIEW
FINAL_REVIEW -> APPROVED
```

For returns:

```text
any verification stage -> RETURNED
RETURNED -> SUBMITTED
```

For rejection:

```text
any verification stage -> REJECTED
```

Only the student who owns the application may resubmit it.

## Error handling

Use clear user-facing error messages. Log server-side exceptions without exposing stack traces to users.

Transactions must be used where multiple database updates must succeed together, especially verification/status/audit operations.

## Deliverable requirements

When generating or modifying the project, provide all source files required to run it in Eclipse. Do not provide pseudocode or omitted sections.

The project must include:

- pom.xml
- Eclipse project configuration
- Java source files
- JSP pages
- CSS/JavaScript
- web.xml if needed
- MySQL schema.sql
- Demo data
- README.md
- Database configuration instructions
- Tomcat deployment instructions
- Demo login credentials

## Compatibility

The supplied project targets:

- Java 11
- Tomcat 9.x
- javax.servlet 4.0.1
- MySQL 8.x

If changing to Tomcat 10/11, migrate the project consistently from `javax.*` to `jakarta.*`; do not mix the APIs.

## Quality requirements

Before returning code, check:

1. All imports exist.
2. Servlet mappings match form actions.
3. JSP links/forms match servlet URLs.
4. DAO SQL matches the schema column names.
5. Every workflow transition is valid.
6. Student ownership checks are present.
7. Officer role checks are present.
8. Database connections are closed safely.
9. PreparedStatements are used.
10. No required source file is omitted.
11. The project can be imported as a Maven WAR project into Eclipse.
12. The WAR can be deployed to Tomcat 9.

When asked to fix a bug, return the complete corrected file(s), not only a fragment, and explain exactly where each file belongs.
