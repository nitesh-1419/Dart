package com.scholarship.servlet;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.model.Application;
import com.scholarship.model.User;
import com.scholarship.service.WorkflowService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.net.URLEncoder;

@WebServlet("/verify")
public class VerifyServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User user = (User) req.getSession().getAttribute("user");

        if (user == null || !isVerifier(user.getRole())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            int id = Integer.parseInt(req.getParameter("applicationId"));
            String action = req.getParameter("action");
            String remarks = req.getParameter("remarks");

            if (remarks == null || remarks.trim().isEmpty()) {
                throw new IllegalArgumentException("Remarks are required.");
            }

            Application app = new ApplicationDAO().findById(id);
            if (app == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            new WorkflowService().process(
                    app,
                    user.getUserId(),
                    user.getRole(),
                    action,
                    remarks.trim()
            );

            resp.sendRedirect(req.getContextPath()
                    + "/officer/dashboard?success="
                    + URLEncoder.encode("Verification recorded", "UTF-8"));

        } catch (IllegalStateException | IllegalArgumentException e) {
            resp.sendRedirect(req.getContextPath()
                    + "/officer/dashboard?error="
                    + URLEncoder.encode(e.getMessage(), "UTF-8"));
        } catch (Exception e) {
            throw new ServletException("Verification failed.", e);
        }
    }

    private boolean isVerifier(String role) {
        return "DOCUMENT_OFFICER".equals(role)
                || "COLLEGE_OFFICER".equals(role)
                || "DISTRICT_OFFICER".equals(role)
                || "FINAL_AUTHORITY".equals(role);
    }
}
