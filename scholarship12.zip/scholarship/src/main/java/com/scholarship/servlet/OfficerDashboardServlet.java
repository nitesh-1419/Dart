package com.scholarship.servlet;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/officer/dashboard")
public class OfficerDashboardServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User user = (User) req.getSession().getAttribute("user");

        if (user == null || !isOfficer(user.getRole())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            req.setAttribute(
                    "applications",
                    new ApplicationDAO().findForRole(user.getRole())
            );

            req.getRequestDispatcher("/officer/dashboard.jsp")
                    .forward(req, resp);

        } catch (Exception e) {
            throw new ServletException("Could not load officer dashboard.", e);
        }
    }

    private boolean isOfficer(String role) {
        return "DOCUMENT_OFFICER".equals(role)
                || "COLLEGE_OFFICER".equals(role)
                || "DISTRICT_OFFICER".equals(role)
                || "FINAL_AUTHORITY".equals(role);
    }
}
