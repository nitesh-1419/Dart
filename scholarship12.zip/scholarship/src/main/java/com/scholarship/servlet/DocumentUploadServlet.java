package com.scholarship.servlet;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.dao.AuditDAO;
import com.scholarship.dao.DocumentDAO;
import com.scholarship.dao.StudentDAO;
import com.scholarship.model.Application;
import com.scholarship.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.file.*;
import java.util.UUID;

@WebServlet("/document/upload")
@MultipartConfig(
        maxFileSize = 5 * 1024 * 1024,
        maxRequestSize = 15 * 1024 * 1024,
        fileSizeThreshold = 1024 * 1024
)
public class DocumentUploadServlet extends HttpServlet {

    private static final String[] ALLOWED_TYPES = {
            "application/pdf", "image/jpeg", "image/png"
    };

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User user = (User) req.getSession().getAttribute("user");

        try {
            int applicationId = Integer.parseInt(req.getParameter("applicationId"));
            String type = req.getParameter("documentType");

            if (!"ID_PROOF".equals(type)
                    && !"MARKSHEET".equals(type)
                    && !"INCOME_CERTIFICATE".equals(type)) {
                throw new IllegalArgumentException("Invalid document type.");
            }

            ApplicationDAO applicationDAO = new ApplicationDAO();
            Application app = applicationDAO.findById(applicationId);

            if (app == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            int studentId = new StudentDAO().findStudentIdByUser(user.getUserId());
            if (!applicationDAO.belongsToStudent(applicationId, studentId)) {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }

            if (!"SUBMITTED".equals(app.getStatus())
                    && !"RETURNED".equals(app.getStatus())) {
                throw new IllegalStateException(
                        "Documents can only be uploaded while the application is awaiting submission/document verification.");
            }

            Part part = req.getPart("file");
            if (part == null || part.getSize() == 0) {
                throw new IllegalArgumentException("File is required.");
            }

            if (!isAllowed(part.getContentType())) {
                throw new IllegalArgumentException(
                        "Only PDF, JPG and PNG files are allowed.");
            }

            String originalName = part.getSubmittedFileName();
            String safeName = UUID.randomUUID() + "-" + safe(originalName);

            Path directory = Paths.get(
                    System.getProperty("java.io.tmpdir"),
                    "scholarship-documents"
            );
            Files.createDirectories(directory);

            Path target = directory.resolve(safeName).normalize();
            if (!target.getParent().equals(directory)) {
                throw new IllegalArgumentException("Invalid file name.");
            }

            Files.copy(
                    part.getInputStream(),
                    target,
                    StandardCopyOption.REPLACE_EXISTING
            );

            new DocumentDAO().save(
                    applicationId,
                    type,
                    originalName,
                    safeName,
                    part.getContentType(),
                    part.getSize()
            );

            new AuditDAO().log(
                    applicationId,
                    user.getUserId(),
                    "DOCUMENT_UPLOADED",
                    "Type=" + type
            );

            resp.sendRedirect(req.getContextPath()
                    + "/student/tracking.jsp?success="
                    + URLEncoder.encode("Document uploaded", "UTF-8"));

        } catch (IllegalArgumentException | IllegalStateException e) {
            resp.sendRedirect(req.getContextPath()
                    + "/student/tracking.jsp?error="
                    + URLEncoder.encode(e.getMessage(), "UTF-8"));
        } catch (Exception e) {
            throw new ServletException("Document upload failed.", e);
        }
    }

    private boolean isAllowed(String contentType) {
        if (contentType == null) return false;
        for (String allowed : ALLOWED_TYPES) {
            if (allowed.equalsIgnoreCase(contentType)) return true;
        }
        return false;
    }

    private String safe(String name) {
        if (name == null || name.trim().isEmpty()) return "file";
        return name.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
}
