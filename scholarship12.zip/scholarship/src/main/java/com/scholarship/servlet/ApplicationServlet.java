package com.scholarship.servlet;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.dao.AuditDAO;
import com.scholarship.dao.StudentDAO;
import com.scholarship.model.User;
import com.scholarship.service.EligibilityService;
import com.scholarship.service.FraudDetectionService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@WebServlet("/application")
public class ApplicationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User user = (User) req.getSession().getAttribute("user");

        if (user == null || !"STUDENT".equals(user.getRole())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            int scholarshipId = Integer.parseInt(req.getParameter("scholarshipId"));

            StudentDAO studentDAO = new StudentDAO();
            int studentId = studentDAO.findStudentIdByUser(user.getUserId());

            if (studentId <= 0) {
                throw new IllegalStateException("Student profile not found.");
            }

            StudentDAO.StudentData data = studentDAO.findData(studentId);
            if (data == null) {
                throw new IllegalStateException("Student profile not found.");
            }

            ApplicationDAO applicationDAO = new ApplicationDAO();

            if (applicationDAO.hasExistingApplication(studentId, scholarshipId)) {
                redirectError(resp, req, "You already have an active application.");
                return;
            }

            EligibilityService.Result eligibility =
                    new EligibilityService().evaluate(data, scholarshipId);

            FraudDetectionService.Result fraud =
                    new FraudDetectionService().assess(studentId, scholarshipId);

            String applicationNo =
                    "SCH-" +
                    DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS")
                            .format(LocalDateTime.now()) +
                    "-" + studentId;

            int applicationId = applicationDAO.create(
                    studentId,
                    scholarshipId,
                    applicationNo,
                    eligibility.eligible ? "ELIGIBLE" : "NOT_ELIGIBLE",
                    eligibility.reason,
                    fraud.score,
                    fraud.risk
            );

            new AuditDAO().log(
                    applicationId,
                    user.getUserId(),
                    "APPLICATION_CREATED",
                    "Eligibility=" + eligibility.eligible +
                    "; Risk=" + fraud.risk +
                    "; " + fraud.reasons
            );

            resp.sendRedirect(req.getContextPath()
                    + "/student/tracking.jsp?success="
                    + URLEncoder.encode(
                            "Application submitted successfully", "UTF-8"));

        } catch (NumberFormatException e) {
            redirectError(resp, req, "Invalid scholarship selection.");
        } catch (IllegalStateException e) {
            redirectError(resp, req, e.getMessage());
        } catch (Exception e) {
            throw new ServletException("Could not create application.", e);
        }
    }

    private void redirectError(HttpServletResponse resp,
                               HttpServletRequest req,
                               String message) throws IOException {
        resp.sendRedirect(req.getContextPath()
                + "/student/apply.jsp?error="
                + URLEncoder.encode(message, "UTF-8"));
    }
}
