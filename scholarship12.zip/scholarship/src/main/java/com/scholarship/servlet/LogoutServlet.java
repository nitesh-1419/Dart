package com.scholarship.servlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        HttpSession s=req.getSession(false);
        if(s!=null)s.invalidate();
        resp.sendRedirect(req.getContextPath()+"/index.jsp?message=Logged+out");
    }
}
