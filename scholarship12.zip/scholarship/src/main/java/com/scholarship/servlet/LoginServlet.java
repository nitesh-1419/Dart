package com.scholarship.servlet;

import com.scholarship.dao.UserDAO;
import com.scholarship.model.User;
import com.scholarship.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        String email=req.getParameter("email");
        String password=req.getParameter("password");
        if(email==null||password==null||email.trim().isEmpty()||password.isEmpty()){
            resp.sendRedirect("index.jsp?error=Email+and+password+are+required");return;
        }
        try{
            User u=new UserDAO().authenticate(email.trim(),PasswordUtil.hash(password));
            if(u==null){resp.sendRedirect("index.jsp?error=Invalid+credentials");return;}
            HttpSession old=req.getSession(false);
            if(old!=null)old.invalidate();
            HttpSession session=req.getSession(true);
            session.setAttribute("user",u);
            session.setMaxInactiveInterval(30*60);
            if("STUDENT".equals(u.getRole()))resp.sendRedirect("student/dashboard.jsp");
            else resp.sendRedirect("officer/dashboard");
        }catch(Exception e){
            throw new ServletException("Login failed",e);
        }
    }
}
