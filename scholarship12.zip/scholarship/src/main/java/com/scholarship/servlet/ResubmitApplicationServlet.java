package com.scholarship.servlet;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.model.Application;
import com.scholarship.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.net.URLEncoder;

@WebServlet("/application/resubmit")
public class ResubmitApplicationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User user = (User) req.getSession().getAttribute("user");
        if (user == null || !"STUDENT".equals(user.getRole())) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            int applicationId = Integer.parseInt(req.getParameter("applicationId"));
            ApplicationDAO dao = new ApplicationDAO();
            Application app = dao.findById(applicationId);

            if (app == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            if (!dao.belongsToStudent(applicationId,
                    new com.scholarship.dao.StudentDAO().findStudentIdByUser(user.getUserId()))) {
                resp.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }

            if (!"RETURNED".equals(app.getStatus())) {
                throw new IllegalStateException("Only returned applications can be resubmitted.");
            }

            dao.updateStatus(applicationId, "SUBMITTED");
            new com.scholarship.dao.AuditDAO().log(
                    applicationId, user.getUserId(), "APPLICATION_RESUBMITTED",
                    "Student resubmitted a returned application.");

            resp.sendRedirect(req.getContextPath() +
                    "/student/tracking.jsp?success=" +
                    URLEncoder.encode("Application resubmitted successfully", "UTF-8"));

        } catch (IllegalStateException | IllegalArgumentException e) {
            resp.sendRedirect(req.getContextPath() +
                    "/student/tracking.jsp?error=" +
                    URLEncoder.encode(e.getMessage(), "UTF-8"));
        } catch (Exception e) {
            throw new ServletException("Could not resubmit application.", e);
        }
    }
}
