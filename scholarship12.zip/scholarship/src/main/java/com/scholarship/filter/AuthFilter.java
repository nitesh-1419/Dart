package com.scholarship.filter;

import com.scholarship.model.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@WebFilter("/*")
public class AuthFilter implements Filter {

    private static final Set<String> PUBLIC_PREFIXES = new HashSet<>(Arrays.asList(
            "/login", "/index.jsp", "/assets/", "/css/", "/js/", "/logout"
    ));

    public void doFilter(ServletRequest req, ServletResponse res,
                         FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String path = request.getRequestURI()
                .substring(request.getContextPath().length());

        boolean publicPath = PUBLIC_PREFIXES.stream()
                .anyMatch(path::startsWith);

        if (publicPath || path.isEmpty() || "/".equals(path)) {
            chain.doFilter(req, res);
            return;
        }

        HttpSession session = request.getSession(false);
        User user = session == null ? null : (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath()
                    + "/index.jsp?error=Please+login");
            return;
        }

        // Prevent students from directly opening officer URLs.
        if (path.startsWith("/officer/")
                && "STUDENT".equals(user.getRole())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        chain.doFilter(req, res);
    }
}
