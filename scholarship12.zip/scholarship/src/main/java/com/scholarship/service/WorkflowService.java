package com.scholarship.service;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.dao.AuditDAO;
import com.scholarship.dao.DocumentDAO;
import com.scholarship.dao.VerificationDAO;
import com.scholarship.model.Application;

import java.sql.SQLException;

public class WorkflowService {

    private final ApplicationDAO applicationDAO = new ApplicationDAO();
    private final VerificationDAO verificationDAO = new VerificationDAO();
    private final AuditDAO auditDAO = new AuditDAO();
    private final DocumentDAO documentDAO = new DocumentDAO();

    public void process(Application app, int verifierId, String role,
                        String action, String remarks) throws SQLException {

        int level;
        String expectedStatus;
        String nextStatus;

        switch (role) {
            case "DOCUMENT_OFFICER":
                level = 1;
                expectedStatus = "SUBMITTED";
                nextStatus = "INSTITUTE_VERIFICATION";
                break;
            case "COLLEGE_OFFICER":
                level = 2;
                expectedStatus = "INSTITUTE_VERIFICATION";
                nextStatus = "DISTRICT_VERIFICATION";
                break;
            case "DISTRICT_OFFICER":
                level = 3;
                expectedStatus = "DISTRICT_VERIFICATION";
                nextStatus = "FINAL_REVIEW";
                break;
            case "FINAL_AUTHORITY":
                level = 4;
                expectedStatus = "FINAL_REVIEW";
                nextStatus = "APPROVED";
                break;
            default:
                throw new IllegalArgumentException("Role cannot verify applications.");
        }

        if (!expectedStatus.equals(app.getStatus())) {
            throw new IllegalStateException(
                    "Application is not assigned to this verification level.");
        }

        if ("APPROVED".equals(action)
                && "DOCUMENT_OFFICER".equals(role)
                && !documentDAO.hasRequiredDocuments(app.getApplicationId())) {
            throw new IllegalStateException(
                    "Upload all three required documents before approving document verification.");
        }

        String finalStatus;
        if ("APPROVED".equals(action)) {
            finalStatus = nextStatus;
        } else if ("REJECTED".equals(action)) {
            finalStatus = "REJECTED";
        } else if ("RETURNED".equals(action)) {
            finalStatus = "RETURNED";
        } else {
            throw new IllegalArgumentException("Invalid verification action.");
        }

        verificationDAO.record(app.getApplicationId(), level, verifierId, action, remarks);
        applicationDAO.updateStatus(app.getApplicationId(), finalStatus);

        auditDAO.log(
                app.getApplicationId(),
                verifierId,
                "VERIFICATION_" + action,
                "Level " + level + "; " + (remarks == null ? "" : remarks)
        );
    }
}
