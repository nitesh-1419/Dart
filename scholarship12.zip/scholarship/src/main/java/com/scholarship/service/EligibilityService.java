package com.scholarship.service;

import com.scholarship.dao.StudentDAO.StudentData;
import com.scholarship.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.time.Period;

public class EligibilityService {
    public Result evaluate(StudentData s,int scholarshipId)throws SQLException {
        String sql="SELECT min_percentage,max_income,min_age,max_age,allowed_course,allowed_years,allowed_categories,allowed_states FROM scholarship_rules WHERE scholarship_id=?";
        try(Connection c=DBConnection.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,scholarshipId);
            try(ResultSet rs=ps.executeQuery()){
                if(!rs.next()) return new Result(false,"No eligibility rules configured.",0);
                double minPct=rs.getDouble("min_percentage"), maxIncome=rs.getDouble("max_income");
                int age=Period.between(s.dob.toLocalDate(), LocalDate.now()).getYears();
                if(s.percentage<minPct)return no("Minimum percentage is "+minPct+"%.");
                if(s.income>maxIncome)return no("Annual income exceeds the permitted limit.");
                if(age<rs.getInt("min_age")||age>rs.getInt("max_age"))return no("Age is outside the permitted range.");
                if(!contains(rs.getString("allowed_course"),s.course))return no("Course is not permitted.");
                if(!contains(rs.getString("allowed_years"),String.valueOf(s.year)))return no("Year of study is not permitted.");
                if(!contains(rs.getString("allowed_categories"),s.category))return no("Category is not permitted.");
                if(!contains(rs.getString("allowed_states"),s.state))return no("Domicile state is not permitted.");
                return new Result(true,"All eligibility rules passed.",0);
            }
        }
    }

    private Result no(String r){return new Result(false,r,0);}
    private boolean contains(String csv,String value){
        if(csv==null||csv.trim().isEmpty())return true;
        for(String x:csv.split(",")) if(x.trim().equalsIgnoreCase(value.trim())) return true;
        return false;
    }

    public static class Result {
        public final boolean eligible; public final String reason; public final int score;
        public Result(boolean e,String r,int s){eligible=e;reason=r;score=s;}
    }
}
