package com.scholarship.service;

import com.scholarship.dao.ApplicationDAO;
import com.scholarship.util.DBConnection;

import java.sql.*;

public class FraudDetectionService {
    public Result assess(int studentId,int scholarshipId) throws SQLException {
        int score=0;
        StringBuilder reasons=new StringBuilder();

        ApplicationDAO dao=new ApplicationDAO();
        if(dao.hasExistingApplication(studentId,scholarshipId)){
            score+=30; reasons.append("Existing active application; ");
        }

        String sql="SELECT annual_income,percentage FROM students WHERE student_id=?";
        try(Connection c=DBConnection.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,studentId);
            try(ResultSet rs=ps.executeQuery()){
                if(rs.next()){
                    if(rs.getDouble("annual_income")<0){score+=50;reasons.append("Invalid negative income; ");}
                    if(rs.getDouble("percentage")<0||rs.getDouble("percentage")>100){score+=50;reasons.append("Invalid academic percentage; ");}
                }
            }
        }

        String risk=score>=61?"HIGH":score>=31?"MEDIUM":"LOW";
        return new Result(score,risk,reasons.length()==0?"No automatic risk indicators found.":reasons.toString());
    }

    public static class Result {
        public final int score; public final String risk; public final String reasons;
        public Result(int s,String r,String x){score=s;risk=r;reasons=x;}
    }
}
