package com.scholarship.dao;

import com.scholarship.model.User;
import com.scholarship.util.DBConnection;

import java.sql.*;

public class UserDAO {
    public User authenticate(String email, String passwordHash) throws SQLException {
        String sql = "SELECT user_id,full_name,email,password_hash,role FROM users WHERE email=? AND password_hash=? AND active=1";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, passwordHash);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                User u = new User();
                u.setUserId(rs.getInt("user_id"));
                u.setFullName(rs.getString("full_name"));
                u.setEmail(rs.getString("email"));
                u.setPasswordHash(rs.getString("password_hash"));
                u.setRole(rs.getString("role"));
                return u;
            }
        }
    }
}
