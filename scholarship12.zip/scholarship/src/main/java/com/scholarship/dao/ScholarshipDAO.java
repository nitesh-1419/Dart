package com.scholarship.dao;

import com.scholarship.model.Scholarship;
import com.scholarship.util.DBConnection;
import java.sql.*;
import java.util.*;

public class ScholarshipDAO {
    public List<Scholarship> findActive() throws SQLException {
        List<Scholarship> list = new ArrayList<>();
        String sql = "SELECT scholarship_id,name,description,amount FROM scholarships WHERE active=1 ORDER BY scholarship_id";
        try (Connection c=DBConnection.getConnection();
             PreparedStatement ps=c.prepareStatement(sql);
             ResultSet rs=ps.executeQuery()) {
            while(rs.next()) {
                Scholarship s=new Scholarship();
                s.setScholarshipId(rs.getInt("scholarship_id"));
                s.setName(rs.getString("name"));
                s.setDescription(rs.getString("description"));
                s.setAmount(rs.getBigDecimal("amount"));
                list.add(s);
            }
        }
        return list;
    }
}
