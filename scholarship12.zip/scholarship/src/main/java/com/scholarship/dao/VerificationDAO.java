package com.scholarship.dao;

import com.scholarship.util.DBConnection;
import java.sql.*;

public class VerificationDAO {
    public void record(int applicationId,int level,int verifierId,String action,String remarks) throws SQLException {
        String sql="INSERT INTO verifications(application_id,level_no,verifier_id,action,remarks) VALUES(?,?,?,?,?)";
        try(Connection c=DBConnection.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,applicationId);ps.setInt(2,level);ps.setInt(3,verifierId);
            ps.setString(4,action);ps.setString(5,remarks);ps.executeUpdate();
        }
    }
}
