package com.scholarship.dao;

import com.scholarship.util.DBConnection;
import java.sql.*;

public class DocumentDAO {

    public void save(int applicationId, String type, String original, String stored,
                     String contentType, long size) throws SQLException {
        String sql = "INSERT INTO documents(" +
                "application_id,document_type,original_name,stored_name,content_type,file_size) " +
                "VALUES(?,?,?,?,?,?)";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, applicationId);
            ps.setString(2, type);
            ps.setString(3, original);
            ps.setString(4, stored);
            ps.setString(5, contentType);
            ps.setLong(6, size);
            ps.executeUpdate();
        }
    }

    public boolean hasRequiredDocuments(int applicationId) throws SQLException {
        String sql = "SELECT COUNT(DISTINCT document_type) FROM documents " +
                     "WHERE application_id=? " +
                     "AND document_type IN ('ID_PROOF','MARKSHEET','INCOME_CERTIFICATE')";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, applicationId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) >= 3;
            }
        }
    }
}
