package com.scholarship.dao;

import com.scholarship.util.DBConnection;
import java.sql.*;

public class AuditDAO {
    public void log(Integer applicationId,Integer userId,String action,String details)throws SQLException{
        String sql="INSERT INTO audit_logs(application_id,user_id,action,details) VALUES(?,?,?,?)";
        try(Connection c=DBConnection.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            if(applicationId==null)ps.setNull(1,Types.INTEGER);else ps.setInt(1,applicationId);
            if(userId==null)ps.setNull(2,Types.INTEGER);else ps.setInt(2,userId);
            ps.setString(3,action);ps.setString(4,details);ps.executeUpdate();
        }
    }
}
