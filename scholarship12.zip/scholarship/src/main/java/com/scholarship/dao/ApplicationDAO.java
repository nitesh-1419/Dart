package com.scholarship.dao;

import com.scholarship.model.Application;
import com.scholarship.util.DBConnection;
import java.sql.*;
import java.util.*;

public class ApplicationDAO {

    public boolean hasExistingApplication(int studentId, int scholarshipId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM applications " +
                     "WHERE student_id=? AND scholarship_id=? AND status NOT IN ('REJECTED')";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, scholarshipId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    public int create(int studentId, int scholarshipId, String applicationNo,
                      String eligibility, String reason, int score, String risk) throws SQLException {
        String sql = "INSERT INTO applications(" +
                "application_no,student_id,scholarship_id,eligibility_status," +
                "eligibility_reason,fraud_score,risk_level,status) " +
                "VALUES(?,?,?,?,?,?,?,'SUBMITTED')";

        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, applicationNo);
            ps.setInt(2, studentId);
            ps.setInt(3, scholarshipId);
            ps.setString(4, eligibility);
            ps.setString(5, reason);
            ps.setInt(6, score);
            ps.setString(7, risk);
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (!rs.next()) throw new SQLException("Application ID was not generated.");
                return rs.getInt(1);
            }
        }
    }

    public List<Application> findByStudent(int studentId) throws SQLException {
        String sql = "SELECT a.*, s.name AS scholarship_name " +
                     "FROM applications a " +
                     "JOIN scholarships s ON a.scholarship_id=s.scholarship_id " +
                     "WHERE a.student_id=? ORDER BY a.submitted_at DESC";
        return find(sql, studentId);
    }

    public List<Application> findForRole(String role) throws SQLException {
        String status;
        switch (role) {
            case "DOCUMENT_OFFICER":
                // A newly submitted application enters document verification here.
                status = "SUBMITTED";
                break;
            case "COLLEGE_OFFICER":
                status = "INSTITUTE_VERIFICATION";
                break;
            case "DISTRICT_OFFICER":
                status = "DISTRICT_VERIFICATION";
                break;
            case "FINAL_AUTHORITY":
                status = "FINAL_REVIEW";
                break;
            default:
                return Collections.emptyList();
        }

        String sql = "SELECT a.*, s.name AS scholarship_name, u.full_name AS student_name " +
                     "FROM applications a " +
                     "JOIN scholarships s ON a.scholarship_id=s.scholarship_id " +
                     "JOIN students st ON a.student_id=st.student_id " +
                     "JOIN users u ON st.user_id=u.user_id " +
                     "WHERE a.status=? ORDER BY a.updated_at";
        return find(sql, status);
    }

    public Application findById(int id) throws SQLException {
        String sql = "SELECT a.*, s.name AS scholarship_name, u.full_name AS student_name " +
                     "FROM applications a " +
                     "JOIN scholarships s ON a.scholarship_id=s.scholarship_id " +
                     "JOIN students st ON a.student_id=st.student_id " +
                     "JOIN users u ON st.user_id=u.user_id " +
                     "WHERE a.application_id=?";
        List<Application> list = find(sql, id);
        return list.isEmpty() ? null : list.get(0);
    }

    public boolean belongsToStudent(int applicationId, int studentId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM applications WHERE application_id=? AND student_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, applicationId);
            ps.setInt(2, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) == 1;
            }
        }
    }

    public void updateStatus(int applicationId, String status) throws SQLException {
        String sql = "UPDATE applications SET status=? WHERE application_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, applicationId);
            ps.executeUpdate();
        }
    }

    private List<Application> find(String sql, Object param) throws SQLException {
        List<Application> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            if (param instanceof Integer) {
                ps.setInt(1, (Integer) param);
            } else {
                ps.setString(1, String.valueOf(param));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    private Application map(ResultSet rs) throws SQLException {
        Application a = new Application();
        a.setApplicationId(rs.getInt("application_id"));
        a.setApplicationNo(rs.getString("application_no"));
        a.setStudentId(rs.getInt("student_id"));
        a.setScholarshipId(rs.getInt("scholarship_id"));
        a.setScholarshipName(rs.getString("scholarship_name"));
        a.setEligibilityStatus(rs.getString("eligibility_status"));
        a.setEligibilityReason(rs.getString("eligibility_reason"));
        a.setFraudScore(rs.getInt("fraud_score"));
        a.setRiskLevel(rs.getString("risk_level"));
        a.setStatus(rs.getString("status"));
        try {
            a.setStudentName(rs.getString("student_name"));
        } catch (SQLException ignored) {
            // student_name is not selected by findByStudent()
        }
        return a;
    }
}
