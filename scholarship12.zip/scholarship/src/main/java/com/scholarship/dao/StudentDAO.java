package com.scholarship.dao;

import com.scholarship.util.DBConnection;
import java.sql.*;

public class StudentDAO {
    public int findStudentIdByUser(int userId) throws SQLException {
        String sql="SELECT student_id FROM students WHERE user_id=?";
        try(Connection c=DBConnection.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,userId);
            try(ResultSet rs=ps.executeQuery()){return rs.next()?rs.getInt(1):-1;}
        }
    }

    public StudentData findData(int studentId) throws SQLException {
        String sql="SELECT s.*,u.full_name FROM students s JOIN users u ON s.user_id=u.user_id WHERE s.student_id=?";
        try(Connection c=DBConnection.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,studentId);
            try(ResultSet rs=ps.executeQuery()){
                if(!rs.next()) return null;
                StudentData d=new StudentData();
                d.studentId=studentId; d.fullName=rs.getString("full_name");
                d.dob=rs.getDate("date_of_birth"); d.course=rs.getString("course");
                d.year=rs.getInt("year_of_study"); d.percentage=rs.getDouble("percentage");
                d.income=rs.getDouble("annual_income"); d.category=rs.getString("category");
                d.state=rs.getString("domicile_state");
                return d;
            }
        }
    }

    public static class StudentData {
        public int studentId; public String fullName,course,category,state;
        public Date dob; public int year; public double percentage,income;
    }
}
