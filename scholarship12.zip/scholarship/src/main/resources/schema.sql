DROP DATABASE IF EXISTS scholarship_db;
CREATE DATABASE scholarship_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE scholarship_db;

CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL UNIQUE,
    password_hash VARCHAR(500) NOT NULL,
    role ENUM('STUDENT','DOCUMENT_OFFICER','COLLEGE_OFFICER','DISTRICT_OFFICER','FINAL_AUTHORITY','ADMIN') NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    roll_no VARCHAR(60) NOT NULL UNIQUE,
    date_of_birth DATE NOT NULL,
    course VARCHAR(120) NOT NULL,
    year_of_study INT NOT NULL,
    percentage DECIMAL(5,2) NOT NULL,
    annual_income DECIMAL(12,2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    domicile_state VARCHAR(100) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE scholarships (
    scholarship_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(180) NOT NULL,
    description TEXT,
    amount DECIMAL(12,2) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE scholarship_rules (
    rule_id INT PRIMARY KEY AUTO_INCREMENT,
    scholarship_id INT NOT NULL UNIQUE,
    min_percentage DECIMAL(5,2) DEFAULT 0,
    max_income DECIMAL(12,2) DEFAULT 999999999,
    min_age INT DEFAULT 0,
    max_age INT DEFAULT 100,
    allowed_course VARCHAR(255),
    allowed_years VARCHAR(100),
    allowed_categories VARCHAR(255),
    allowed_states VARCHAR(500),
    required_documents VARCHAR(500),
    FOREIGN KEY (scholarship_id) REFERENCES scholarships(scholarship_id)
);

CREATE TABLE applications (
    application_id INT PRIMARY KEY AUTO_INCREMENT,
    application_no VARCHAR(40) NOT NULL UNIQUE,
    student_id INT NOT NULL,
    scholarship_id INT NOT NULL,
    eligibility_status ENUM('PENDING','ELIGIBLE','NOT_ELIGIBLE') NOT NULL DEFAULT 'PENDING',
    eligibility_reason TEXT,
    fraud_score INT NOT NULL DEFAULT 0,
    risk_level ENUM('LOW','MEDIUM','HIGH') NOT NULL DEFAULT 'LOW',
    status ENUM('SUBMITTED','DOCUMENT_VERIFICATION','INSTITUTE_VERIFICATION','DISTRICT_VERIFICATION','FINAL_REVIEW','RETURNED','REJECTED','APPROVED') NOT NULL DEFAULT 'SUBMITTED',
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (scholarship_id) REFERENCES scholarships(scholarship_id),
    INDEX idx_application_student(student_id),
    INDEX idx_application_status(status)
);

CREATE TABLE documents (
    document_id INT PRIMARY KEY AUTO_INCREMENT,
    application_id INT NOT NULL,
    document_type VARCHAR(80) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    content_type VARCHAR(100) NOT NULL,
    file_size BIGINT NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verification_status ENUM('PENDING','VERIFIED','REJECTED') DEFAULT 'PENDING',
    FOREIGN KEY (application_id) REFERENCES applications(application_id)
);

CREATE TABLE verifications (
    verification_id INT PRIMARY KEY AUTO_INCREMENT,
    application_id INT NOT NULL,
    level_no INT NOT NULL,
    verifier_id INT NOT NULL,
    action ENUM('APPROVED','REJECTED','RETURNED') NOT NULL,
    remarks VARCHAR(1000),
    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES applications(application_id),
    FOREIGN KEY (verifier_id) REFERENCES users(user_id),
    INDEX idx_verification_application(application_id)
);

CREATE TABLE audit_logs (
    audit_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    application_id INT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    details VARCHAR(1000),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES applications(application_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE notifications (
    notification_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    message VARCHAR(1000) NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

INSERT INTO users(full_name,email,password_hash,role) VALUES
('System Admin','admin@demo.com','240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9','ADMIN'),
('Document Officer','doc@demo.com','118b8d35a17bcf2c7d2d790509e12308dc6332c5d234f0098d2d6be6700bebb1','DOCUMENT_OFFICER'),
('College Officer','college@demo.com','118b8d35a17bcf2c7d2d790509e12308dc6332c5d234f0098d2d6be6700bebb1','COLLEGE_OFFICER'),
('District Officer','district@demo.com','118b8d35a17bcf2c7d2d790509e12308dc6332c5d234f0098d2d6be6700bebb1','DISTRICT_OFFICER'),
('Final Authority','final@demo.com','118b8d35a17bcf2c7d2d790509e12308dc6332c5d234f0098d2d6be6700bebb1','FINAL_AUTHORITY'),
('Demo Student','student@demo.com','703b0a3d6ad75b649a28adde7d83c6251da457549263bc7ff45ec709b0a8448b','STUDENT');

INSERT INTO students(user_id,roll_no,date_of_birth,course,year_of_study,percentage,annual_income,category,domicile_state)
VALUES(6,'STU001','2006-05-12','BSc IT',2,78.50,180000,'GENERAL','Maharashtra');

INSERT INTO scholarships(name,description,amount,active)
VALUES
('Merit & Need Scholarship','Merit-based scholarship for eligible undergraduate students.',25000,TRUE),
('Technology Student Scholarship','Support for students studying technology-related programs.',30000,TRUE);

INSERT INTO scholarship_rules
(scholarship_id,min_percentage,max_income,min_age,max_age,allowed_course,allowed_years,allowed_categories,allowed_states,required_documents)
VALUES
(1,60,300000,16,30,'BSc IT,BCA,BSc Computer Science','1,2,3,4','GENERAL,OBC,SC,ST','Maharashtra,Gujarat,Goa','ID_PROOF,MARKSHEET,INCOME_CERTIFICATE'),
(2,65,500000,16,30,'BSc IT,BCA,BTech','1,2,3,4','GENERAL,OBC,SC,ST','Maharashtra,Goa','ID_PROOF,MARKSHEET,INCOME_CERTIFICATE');
