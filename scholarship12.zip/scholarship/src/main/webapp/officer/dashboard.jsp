<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*,com.scholarship.model.*" %>
<%
User u=(User)session.getAttribute("user");
if(u==null || "STUDENT".equals(u.getRole())){
    response.sendRedirect("../index.jsp");
    return;
}
List<Application> apps=(List<Application>)request.getAttribute("applications");
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Officer Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/app.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <span class="navbar-brand">Scholarship Verification — <%=u.getRole()%></span>
        <a class="btn btn-outline-light btn-sm" href="../logout">Logout</a>
    </div>
</nav>

<div class="container py-4">
    <%if(request.getParameter("success")!=null){%>
        <div class="alert alert-success"><%=request.getParameter("success")%></div>
    <%}%>
    <%if(request.getParameter("error")!=null){%>
        <div class="alert alert-danger"><%=request.getParameter("error")%></div>
    <%}%>

    <h3>Pending Applications</h3>
    <p class="text-muted">
        Approving moves the application to the next verification level.
        Return sends it back to the student; Reject ends the workflow.
    </p>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle bg-white">
            <thead>
                <tr>
                    <th>Application</th>
                    <th>Student</th>
                    <th>Eligibility</th>
                    <th>Risk</th>
                    <th>Status</th>
                    <th style="min-width:320px">Action</th>
                </tr>
            </thead>
            <tbody>
            <%if(apps!=null && !apps.isEmpty()) for(Application a:apps){%>
                <tr>
                    <td><%=a.getApplicationNo()%></td>
                    <td><%=a.getStudentName()%></td>
                    <td><%=a.getEligibilityStatus()%><br>
                        <small><%=a.getEligibilityReason()%></small>
                    </td>
                    <td>
                        <span class="risk-<%=a.getRiskLevel().toLowerCase()%>">
                            <%=a.getRiskLevel()%>
                        </span>
                        (<%=a.getFraudScore()%>)
                    </td>
                    <td><%=a.getStatus()%></td>
                    <td>
                        <form method="post" action="../verify">
                            <input type="hidden" name="applicationId"
                                   value="<%=a.getApplicationId()%>">
                            <input name="remarks" class="form-control form-control-sm mb-1"
                                   placeholder="Remarks" required>
                            <div class="btn-group">
                                <button name="action" value="APPROVED"
                                        class="btn btn-success btn-sm">Approve</button>
                                <button name="action" value="RETURNED"
                                        class="btn btn-warning btn-sm">Return</button>
                                <button name="action" value="REJECTED"
                                        class="btn btn-danger btn-sm">Reject</button>
                            </div>
                        </form>
                    </td>
                </tr>
            <%} else {%>
                <tr>
                    <td colspan="6" class="text-center py-4">
                        No pending applications for this verification level.
                    </td>
                </tr>
            <%}%>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
