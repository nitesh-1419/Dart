<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Scholarship System - Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/app.css">
</head>
<body class="bg-light">
<div class="container py-5">
<div class="row justify-content-center"><div class="col-md-6 col-lg-5">
<div class="card shadow-sm border-0"><div class="card-body p-4">
<h2 class="fw-bold mb-1">Scholarship Portal</h2>
<p class="text-muted">Application & Multi-Level Verification</p>
<% if(request.getParameter("error")!=null){ %><div class="alert alert-danger"><%=request.getParameter("error")%></div><% } %>
<% if(request.getParameter("message")!=null){ %><div class="alert alert-success"><%=request.getParameter("message")%></div><% } %>
<form method="post" action="login">
<label class="form-label">Email</label>
<input class="form-control mb-3" type="email" name="email" required>
<label class="form-label">Password</label>
<input class="form-control mb-3" type="password" name="password" required>
<button class="btn btn-primary w-100">Login</button>
</form>
<hr>
<small class="text-muted">
Demo: student@demo.com / student123<br>
Officer: doc@demo.com / officer123
</small>
</div></div></div></div></div>
</body></html>
