<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="com.scholarship.model.User" %>
<%
User u=(User)session.getAttribute("user");
if(u==null){response.sendRedirect("../index.jsp");return;}
%>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Student Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><nav class="navbar navbar-dark bg-primary"><div class="container"><span class="navbar-brand">Scholarship Portal</span><a class="btn btn-light btn-sm" href="../logout">Logout</a></div></nav>
<div class="container py-5"><h2>Welcome, <%=u.getFullName()%></h2><div class="row g-3 mt-2">
<div class="col-md-4"><div class="card p-4 shadow-sm"><h5>Apply</h5><p>Check scholarship eligibility and submit an application.</p><a href="apply.jsp" class="btn btn-primary">New Application</a></div></div>
<div class="col-md-4"><div class="card p-4 shadow-sm"><h5>Track</h5><p>View verification progress and risk status.</p><a href="tracking.jsp" class="btn btn-outline-primary">Track Applications</a></div></div>
</div></div></body></html>
