<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*,com.scholarship.model.*,com.scholarship.dao.*" %>
<%
User u=(User)session.getAttribute("user");
if(u==null || !"STUDENT".equals(u.getRole())){
    response.sendRedirect("../index.jsp");
    return;
}
int sid=new StudentDAO().findStudentIdByUser(u.getUserId());
List<Application> apps=new ApplicationDAO().findByStudent(sid);
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Track Applications</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/app.css">
</head>
<body class="bg-light">
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>My Applications</h2>
        <div>
            <a class="btn btn-outline-primary btn-sm" href="dashboard.jsp">Dashboard</a>
            <a class="btn btn-outline-danger btn-sm" href="../logout">Logout</a>
        </div>
    </div>

    <% if(request.getParameter("success")!=null){ %>
        <div class="alert alert-success"><%=request.getParameter("success")%></div>
    <% } %>
    <% if(request.getParameter("error")!=null){ %>
        <div class="alert alert-danger"><%=request.getParameter("error")%></div>
    <% } %>

    <% if(apps.isEmpty()){ %>
        <div class="card shadow-sm"><div class="card-body text-center">
            No applications found. <a href="apply.jsp">Apply for a scholarship</a>.
        </div></div>
    <% } %>

    <% for(Application a:apps){ %>
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <div class="d-flex justify-content-between flex-wrap gap-2">
                <h5><%=a.getApplicationNo()%></h5>
                <span class="badge bg-primary"><%=a.getStatus()%></span>
            </div>

            <p><strong>Scholarship:</strong> <%=a.getScholarshipName()%></p>
            <p><strong>Eligibility:</strong>
                <%=a.getEligibilityStatus()%> — <%=a.getEligibilityReason()%>
            </p>
            <p><strong>Risk:</strong>
                <span class="risk-<%=a.getRiskLevel().toLowerCase()%>">
                    <%=a.getRiskLevel()%> (<%=a.getFraudScore()%>)
                </span>
            </p>

            <div class="status-step done">
                1. Application Submitted
            </div>
            <div class="status-step <%=a.getStatus().equals("SUBMITTED")?"current":
                    isAfter(a.getStatus(),"SUBMITTED")?"done":""%>">
                2. Document Verification
            </div>
            <div class="status-step <%=a.getStatus().equals("INSTITUTE_VERIFICATION")?"current":
                    isAfter(a.getStatus(),"INSTITUTE_VERIFICATION")?"done":""%>">
                3. Institute Verification
            </div>
            <div class="status-step <%=a.getStatus().equals("DISTRICT_VERIFICATION")?"current":
                    isAfter(a.getStatus(),"DISTRICT_VERIFICATION")?"done":""%>">
                4. District Verification
            </div>
            <div class="status-step <%=a.getStatus().equals("FINAL_REVIEW")?"current":
                    isAfter(a.getStatus(),"FINAL_REVIEW")?"done":""%>">
                5. Final Review
            </div>
            <div class="status-step <%=a.getStatus().equals("APPROVED")?"done":""%>">
                6. Final Decision
            </div>

            <% if("REJECTED".equals(a.getStatus())){ %>
                <div class="alert alert-danger mt-3 mb-0">
                    Application rejected by verification workflow.
                </div>
            <% } %>

            <% if("RETURNED".equals(a.getStatus())){ %>
                <div class="alert alert-warning mt-3">
                    This application was returned for correction. Upload corrected documents if required,
                    then resubmit it.
                </div>
                <form action="../application/resubmit" method="post">
                    <input type="hidden" name="applicationId" value="<%=a.getApplicationId()%>">
                    <button class="btn btn-warning">Resubmit Application</button>
                </form>
            <% } %>

            <% if("SUBMITTED".equals(a.getStatus()) || "RETURNED".equals(a.getStatus())){ %>
                <hr>
                <h6>Upload Document</h6>
                <form action="../document/upload" method="post"
                      enctype="multipart/form-data" class="row g-2">
                    <input type="hidden" name="applicationId"
                           value="<%=a.getApplicationId()%>">

                    <div class="col-md-4">
                        <select name="documentType" class="form-select" required>
                            <option value="ID_PROOF">ID Proof</option>
                            <option value="MARKSHEET">Marksheet</option>
                            <option value="INCOME_CERTIFICATE">Income Certificate</option>
                        </select>
                    </div>

                    <div class="col-md-5">
                        <input type="file" name="file" class="form-control"
                               accept=".pdf,.jpg,.jpeg,.png" required>
                    </div>

                    <div class="col-md-3">
                        <button class="btn btn-outline-primary w-100">Upload</button>
                    </div>
                </form>
                <small class="text-muted">
                    Maximum 5 MB per file. Accepted formats: PDF, JPG, PNG.
                </small>
            <% } %>
        </div>
    </div>
    <% } %>
</div>
</body>
</html>

<%!
private boolean isAfter(String status,String step){
    if("RETURNED".equals(status) || "REJECTED".equals(status)) return false;
    String[] order={
        "SUBMITTED",
        "INSTITUTE_VERIFICATION",
        "DISTRICT_VERIFICATION",
        "FINAL_REVIEW",
        "APPROVED"
    };
    int a=java.util.Arrays.asList(order).indexOf(status);
    int b=java.util.Arrays.asList(order).indexOf(step);
    return a>b;
}
%>
