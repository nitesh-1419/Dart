<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*,com.scholarship.dao.ScholarshipDAO,com.scholarship.model.Scholarship" %>
<%
if(session.getAttribute("user")==null){response.sendRedirect("../index.jsp");return;}
List<Scholarship> list=new ScholarshipDAO().findActive();
%>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Apply</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body><div class="container py-5"><a href="dashboard.jsp">← Dashboard</a><h2 class="mt-3">Scholarship Application</h2>
<%if(request.getParameter("error")!=null){%><div class="alert alert-danger"><%=request.getParameter("error")%></div><%}%>
<div class="alert alert-info">The system automatically checks your student profile against the scholarship rules and calculates a risk score.</div>
<form method="post" action="../application" class="card p-4 shadow-sm">
<label class="form-label">Select Scholarship</label>
<select name="scholarshipId" class="form-select mb-3" required>
<%for(Scholarship s:list){%><option value="<%=s.getScholarshipId()%>"><%=s.getName()%> — ₹<%=s.getAmount()%></option><%}%>
</select>
<button class="btn btn-primary">Submit Application</button>
</form></div></body></html>
