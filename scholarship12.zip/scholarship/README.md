# Scholarship Application & Multi-Level Verification System

An Eclipse/Tomcat-ready academic project using:

- Java 11
- JSP
- Servlets 4
- JDBC
- MySQL 8+
- Bootstrap 5
- HTML/CSS/JavaScript
- Maven WAR
- Apache Tomcat 9.x

## Modules

1. Student login
2. Scholarship listing
3. Eligibility engine
4. Application submission
5. Document upload
6. Rule-based risk/fraud scoring
7. Four-level verification workflow
8. Return/re-submission workflow
9. Application tracking
10. Audit logging
11. Role-based access

## Correct workflow

```text
Student submits
      |
      v
SUBMITTED
      |
      v
Document Officer
      |
      +---- Return ----> RETURNED -> Student corrects/uploads -> Resubmit
      |
      +---- Reject ----> REJECTED
      |
      +---- Approve --> INSTITUTE_VERIFICATION
                              |
                              v
                       College Officer
                              |
                              +---- Approve --> DISTRICT_VERIFICATION
                                                   |
                                                   v
                                            District Officer
                                                   |
                                                   +---- Approve --> FINAL_REVIEW
                                                                        |
                                                                        v
                                                                  Final Authority
                                                                        |
                                                                        v
                                                                    APPROVED
```

The supplied original project had a workflow mismatch: new applications were stored as
`SUBMITTED`, while the document officer dashboard searched for `DOCUMENT_VERIFICATION`.
This version fixes that so the first verification level can actually see new applications.

## Requirements

Install:

- JDK 11 or newer
- Eclipse IDE for Enterprise Java and Web Developers
- Apache Tomcat 9.x
- MySQL 8.x
- Maven (or use Eclipse m2e)

Tomcat 9 is used because this project uses the `javax.servlet.*` API.
Do not deploy this exact project to Tomcat 10/11 without migrating to `jakarta.*`.

## 1. Create the MySQL database

Open MySQL Workbench or the MySQL command line and run:

```sql
SOURCE /path/to/project/src/main/resources/schema.sql;
```

Or from a terminal:

```bash
mysql -u root -p < src/main/resources/schema.sql
```

The script creates:

```text
Database: scholarship_db
Username: root
Password: root
```

The demo connection is configured in:

```text
src/main/java/com/scholarship/util/DBConnection.java
```

If your MySQL password is different, change:

```java
private static final String PASSWORD = "root";
```

Do not use the demo password in a real deployment.

## 2. Import into Eclipse

### Recommended: Maven import

1. Open Eclipse.
2. `File` -> `Import`.
3. Select `Maven` -> `Existing Maven Projects`.
4. Select the project root folder.
5. Click `Finish`.
6. Wait for Maven dependencies to download.

The project is packaged as:

```text
scholarship-system.war
```

### Add Tomcat

1. `Window` -> `Show View` -> `Servers`.
2. Create a new `Apache Tomcat v9.0 Server`.
3. Select your Tomcat installation directory.
4. Add `scholarship-verification-system` to the server.
5. Start the server.

Open:

```text
http://localhost:8080/scholarship-system/
```

If Eclipse assigns a different context path, use that path.

## 3. Demo accounts

| Role | Email | Password |
|---|---|---|
| Student | student@demo.com | student123 |
| Document Officer | doc@demo.com | officer123 |
| College Officer | college@demo.com | officer123 |
| District Officer | district@demo.com | officer123 |
| Final Authority | final@demo.com | officer123 |
| Admin | admin@demo.com | admin123 |

## 4. Test the complete workflow

### Student

1. Login as `student@demo.com`.
2. Open `New Application`.
3. Select a scholarship.
4. Submit.
5. Open `Track Applications`.
6. Upload:
   - ID Proof
   - Marksheet
   - Income Certificate

### Document Officer

1. Logout.
2. Login as `doc@demo.com`.
3. The submitted application appears in the dashboard.
4. Click `Approve`.
5. It moves to `INSTITUTE_VERIFICATION`.

### College Officer

Login as:

```text
college@demo.com
```

Approve the application.

### District Officer

Login as:

```text
district@demo.com
```

Approve the application.

### Final Authority

Login as:

```text
final@demo.com
```

Approve the application.

The final status becomes:

```text
APPROVED
```

## 5. Test Return / Resubmission

At any verification level:

1. Enter remarks.
2. Click `Return`.
3. The application becomes `RETURNED`.
4. Student logs in.
5. Student can upload corrected documents.
6. Student clicks `Resubmit Application`.
7. The application becomes `SUBMITTED`.
8. It returns to the document-verification queue.

## 6. Project structure

```text
scholarship-verification-system/
|
+-- pom.xml
+-- README.md
|
+-- src/main/java/com/scholarship/
|   +-- dao/
|   |   +-- ApplicationDAO.java
|   |   +-- AuditDAO.java
|   |   +-- DocumentDAO.java
|   |   +-- ScholarshipDAO.java
|   |   +-- StudentDAO.java
|   |   +-- UserDAO.java
|   |   +-- VerificationDAO.java
|   |
|   +-- model/
|   |   +-- Application.java
|   |   +-- Scholarship.java
|   |   +-- User.java
|   |
|   +-- service/
|   |   +-- EligibilityService.java
|   |   +-- FraudDetectionService.java
|   |   +-- WorkflowService.java
|   |
|   +-- servlet/
|   |   +-- ApplicationServlet.java
|   |   +-- DocumentUploadServlet.java
|   |   +-- LoginServlet.java
|   |   +-- LogoutServlet.java
|   |   +-- OfficerDashboardServlet.java
|   |   +-- ResubmitApplicationServlet.java
|   |   +-- VerifyServlet.java
|   |
|   +-- filter/
|       +-- AuthFilter.java
|       +-- SecurityHeaderFilter.java
|   |
|   +-- util/
|       +-- DBConnection.java
|       +-- PasswordUtil.java
|
+-- src/main/resources/
|   +-- schema.sql
|
+-- src/main/webapp/
    +-- index.jsp
    +-- assets/app.css
    +-- student/
    |   +-- apply.jsp
    |   +-- dashboard.jsp
    |   +-- tracking.jsp
    |
    +-- officer/
    |   +-- dashboard.jsp
    |
    +-- WEB-INF/
        +-- web.xml
```

## 7. Build from Eclipse terminal

From the project root:

```bash
mvn clean package
```

The WAR is created at:

```text
target/scholarship-system.war
```

## Important academic-project notes

This is suitable as an academic/demo implementation. Before production use, add:

- BCrypt/Argon2id password hashing instead of SHA-256
- CSRF protection
- HTTPS
- database connection pooling
- secure secret management
- antivirus/content scanning for uploaded documents
- MIME/content validation rather than trusting browser MIME types
- controlled document storage instead of the system temporary directory
- stronger authorization and audit controls
- rate limiting and account lockout
- database migrations
- centralized error handling/logging
- secure cookie settings
- notification delivery
